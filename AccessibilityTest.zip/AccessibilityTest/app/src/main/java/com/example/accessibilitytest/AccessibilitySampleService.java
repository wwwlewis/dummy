package com.example.accessibilitytest;

/**
 * Created by popfisher on 2017/7/6.
 */
import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.annotation.TargetApi;
import android.view.accessibility.AccessibilityEvent;
import android.util.Log;
import androidx.core.app.ActivityCompat;
import android.view.accessibility.AccessibilityNodeInfo;

@TargetApi(16)
public class AccessibilitySampleService extends AccessibilityService {
    private final AccessibilityServiceInfo info = new AccessibilityServiceInfo();

    private static final String TAG = "AccessibilitySampleService";
    private static final String TAGEVENTS = "TAGEVENTS";
    private String currntApplicationPackage = "";

    private final int REQUEST_PERMISSION_PHONE_STATE=1;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();

        // 通过代码可以动态配置，但是可配置项少一点
//        AccessibilityServiceInfo accessibilityServiceInfo = new AccessibilityServiceInfo();
//        accessibilityServiceInfo.eventTypes = AccessibilityEvent.TYPE_WINDOWS_CHANGED
//                | AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
//                | AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
//                | AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED;
//        accessibilityServiceInfo.feedbackType = AccessibilityServiceInfo.FEEDBACK_ALL_MASK;
//        accessibilityServiceInfo.notificationTimeout = 0;
//        accessibilityServiceInfo.flags = AccessibilityServiceInfo.DEFAULT;
//        setServiceInfo(accessibilityServiceInfo);

        Log.d(TAG, "onServiceConnected");
        info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.notificationTimeout = 100;

        //requestPermission(Manifest.permission.READ_SMS, REQUEST_PERMISSION_PHONE_STATE);
        //requestPermission(Manifest.permission.READ_CONTACTS, REQUEST_PERMISSION_PHONE_STATE);

        this.setServiceInfo(info);

    }


    @Override
    public void onAccessibilityEvent(AccessibilityEvent accessibilityEvent) {

        System.out.print("onAccessibilityEvent");
        Log.d(TAG, "onAccessibilityEvent");
        final String sourcePackageName = (String) accessibilityEvent.getPackageName();
        currntApplicationPackage = sourcePackageName;
        Log.d(TAG, "sourcePackageName:" + sourcePackageName);
        Log.d(TAG, "parcelable:" + accessibilityEvent.getText().toString());

        // windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        // check for which events you want
        if (accessibilityEvent.getEventType() == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
            Log.d(TAGEVENTS, "TYPE_VIEW_TEXT_CHANGED");
            Log.d(TAGEVENTS, accessibilityEvent.getText().toString());
            //accessibilityEvent.getText().toString() will give all text which user typed in input box

            //windowController.notifyDatasetChanged(accessibilityEvent.getText().toString(), currntApplicationPackage);
        }

    }

    @Override
    public void onInterrupt() {

    }
}