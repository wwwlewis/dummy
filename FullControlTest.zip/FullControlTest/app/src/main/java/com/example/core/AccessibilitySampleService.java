package com.example.core;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.InstallSourceInfo;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;

import java.util.ArrayList;
import java.util.List;



public class AccessibilitySampleService extends AccessibilityService {
    private final AccessibilityServiceInfo info = new AccessibilityServiceInfo();

    private static final String TAG = "AccessibilitySampleService";
    private static final String TAGEVENTS = "TAGEVENTS";
    private String currntApplicationPackage = "";

    private final int REQUEST_PERMISSION_PHONE_STATE = 1;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();

        // 通过代码可以动态配置，但是可配置项少一点
//        AccessibilityServiceInfo accessibilityServiceInfo = new AccessibilityServiceInfo();
//        accessibilityServiceInfo.eventTypes = AccessibilityEvent.TYPE_WINDOWS_CHANGED
//                | AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
//                | AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
//                | AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED;
//        accessibilityServiceInfo.feedbackType = AccessibilityServiceInfo.FEEDBACK_ALL_MASK;
//        accessibilityServiceInfo.notificationTimeout = 0;
//        accessibilityServiceInfo.flags = AccessibilityServiceInfo.DEFAULT;
//        setServiceInfo(accessibilityServiceInfo);

        //       Log.d(TAG, "onServiceConnected");
        //       info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK;
        //       info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        //       info.notificationTimeout = 100;

        //requestPermission(Manifest.permission.READ_SMS, REQUEST_PERMISSION_PHONE_STATE);
        //requestPermission(Manifest.permission.READ_CONTACTS, REQUEST_PERMISSION_PHONE_STATE);

        /* ORGINAL OK
        Log.d(TAG, "onServiceConnected");
        info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.notificationTimeout = 100;
        this.setServiceInfo(info);
         */

        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_AUDIBLE | AccessibilityServiceInfo.FEEDBACK_VISUAL;
        //info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK;
        info.eventTypes = AccessibilityEvent.TYPE_VIEW_CLICKED | AccessibilityEvent.TYPE_VIEW_LONG_CLICKED | AccessibilityEvent.TYPE_VIEW_SELECTED | AccessibilityEvent.TYPE_VIEW_FOCUSED | AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED | AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED | AccessibilityEvent.TYPE_VIEW_SCROLLED | AccessibilityEvent.TYPE_WINDOWS_CHANGED;

        info.flags = AccessibilityServiceInfo.DEFAULT | AccessibilityServiceInfo.FLAG_REQUEST_ENHANCED_WEB_ACCESSIBILITY | AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS | AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        info.notificationTimeout = 0;
        this.setServiceInfo(info);

    }


    @Override
    public void onAccessibilityEvent(AccessibilityEvent accessibilityEvent) {

        System.out.print("onAccessibilityEvent");
        Log.d(TAG, "onAccessibilityEvent");
        final String sourcePackageName = (String) accessibilityEvent.getPackageName();
        currntApplicationPackage = sourcePackageName;
        Log.d(TAG, "sourcePackageName:" + sourcePackageName);
        Log.d(TAG, "parcelable:" + accessibilityEvent.getText().toString());

        if (accessibilityEvent.getText().toString().equals("[enabled]")){
            Log.d(TAG, "enabled_services:" + getAccessServiceList().toString());

        }

        // windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        // check for which events you want
        if (accessibilityEvent.getEventType() == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
            Log.d(TAGEVENTS, "TYPE_VIEW_TEXT_CHANGED");
            Log.d(TAGEVENTS, accessibilityEvent.getText().toString());
            //accessibilityEvent.getText().toString() will give all text which user typed in input box

            //windowController.notifyDatasetChanged(accessibilityEvent.getText().toString(), currntApplicationPackage);

        }


    }

    @Override
    public void onInterrupt() {

    }

    public List<AccessibilityServiceInfo> getAccessServiceList() {

        PackageManager pm = getPackageManager();

        List<AccessibilityServiceInfo> result = new ArrayList<>();
        AccessibilityManager accessibilityManager = (AccessibilityManager) getApplicationContext().getSystemService(Context.ACCESSIBILITY_SERVICE);
        if (accessibilityManager == null) {
            return result;
        }

        List<AccessibilityServiceInfo> infoList = accessibilityManager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        if (infoList == null || infoList.size() == 0) {
            return result;
        }
        for (AccessibilityServiceInfo info : infoList) {
            result.add(info);
            String id = info.getId();
            Log.d(TAG, "id is ==>" + id);

            String[] packages = id.split("/");
            try {
                String installer = pm.getInstallerPackageName(packages[0]);
                Log.d(TAG, "Installer for " + packages[0] + " is " + installer);
            }catch (Exception e) {
                e.printStackTrace();
            }
        }

        return result;
    }
}
